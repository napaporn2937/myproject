<script type="text/javascript" src="<?php echo base_url("assets/plugins/jquery.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/jquery-ui/jquery-ui.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/bootstrap/js/bootstrap.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/jquery.blockui.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/jquery.cokie.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/uniform/jquery.uniform.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/select2/select2.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/datatables/media/js/jquery.dataTables.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/metronic.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/layout.js") ?>"></script>
<script type="text/javascript">
	$(document).ready(function(){
		Metronic.init(); 
		Layout.init()
	})
</script>